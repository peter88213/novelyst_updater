[Project homepage](https://peter88213.github.io/novelyst_updater) > Instructions for use

--- 

A [novelyst](https://peter88213.github.io/novelyst/) plugin. 

---

# Installation

If [novelyst](https://peter88213.github.io/novelyst/) is installed, the setup script auto-installs the *novelyst_updater* plugin in the *novelyst* plugin directory.


---

# Operation

---

# License

This is Open Source software, and the *novelyst_updater* plugin is licensed under GPLv3. See the
[GNU General Public License website](https://www.gnu.org/licenses/gpl-3.0.en.html) for more
details, or consult the [LICENSE](https://github.com/peter88213/novelyst_updater/blob/main/LICENSE) file.
