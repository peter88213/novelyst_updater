"""An update checker plugin for novelyst.

Requires Python 3.6+
Copyright (c) 2023 Peter Triesberger
For further information see https://github.com/peter88213/novelyst_updater
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

"""
import sys
import os
from tkinter import messagebox
import locale
import gettext
from urllib.request import urlopen
import webbrowser

LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation('novelyst_updater', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):

        return message


class CancelCheck(Exception):
    pass


class Plugin:
    """Template plugin class.
    
    Public methods:
        install(ui) -- Install the plugin and extend the novelyst user interface.
    """
    VERSION = '0.2.2'
    NOVELYST_API = '4.36'
    DESCRIPTION = 'Plugin template'
    URL = 'https://peter88213.github.io/novelyst_updater'
    _HELP_URL = 'https://peter88213.github.io/novelyst_updater/usage'

    def install(self, ui):
        """Install the plugin and extend the novelyst user interface.
        
        Positional arguments:
            ui -- reference to the NovelystTk instance of the application.
        """
        self._ui = ui

        self._ui.helpMenu.add_command(label=_('novelyst_updater Online help'), command=lambda: webbrowser.open(self._HELP_URL))

        self._ui.toolsMenu.add_command(label=_('Check for updates'), command=self._check_for_updates)

    def _check_for_updates(self):
        found = False
        print('Check for updates')

        repoName = 'novelyst'
        print(repoName)
        try:
            majorVersion, minorVersion, patchlevel, downloadUrl = self._get_version_info(repoName)
        except:
            messagebox.showerror(_('Check for updates'), _('No online update information for novelyst found.'))
            return

        try:
            if self._update_available((majorVersion, minorVersion, patchlevel),
                                     (self._ui.plugins.majorVersion, self._ui.plugins.minorVersion, self._ui.plugins.patchlevel)):
                self._download_update('novelyst', downloadUrl)
                found = True

            for repoName in self._ui.plugins:
                print(repoName)
                try:
                    majorVersion, minorVersion, patchlevel, downloadUrl = self._get_version_info(repoName)
                    latest = (majorVersion, minorVersion, patchlevel)

                    majorVersion, minorVersion, patchlevel = self._ui.plugins[repoName].VERSION.split('.')
                    current = (int(majorVersion), int(minorVersion), int(patchlevel))
                except:
                    continue
                else:
                    if self._update_available(latest, current):
                        self._download_update(repoName, downloadUrl)
                        found = True
            if not found:
                messagebox.showinfo(_('Check for updates'), _('No updates available.'))
        except CancelCheck:
            pass

    def _download_update(self, repo, downloadUrl):
        """Start the web browser with downloadUrl on demand.
        
        Positional arguments:
            repo: str -- Repository name of the app or plugin.
            downloadUrl: str -- Download URL of the latest release in the repository.
        
        Exceptions:
            raise CancelCheck, if the update check is to be cancelled.
        """
        text = f'{_("An update is available for")} {repo}.\n{_("Start your web browser for download?")}'
        answer = messagebox.askyesnocancel(_('Check for updates'), text)
        if answer:
            webbrowser.open(downloadUrl)
        elif answer is None:
            raise CancelCheck

    def _get_version_info(self, repoName):
        """Return version information and download URL stored in a repository's VERSION file.
        
        Positional arguments:
            repoName: str -- The repository's name.
        
        Return major version number, minor version number, patch level, and download URL.        
        """
        versionUrl = f'https://github.com/peter88213/{repoName}/raw/main/VERSION'
        data = urlopen(versionUrl)
        downloadUrl = None
        version = None
        lines = data.read().decode('utf-8').split('\n')
        for line in lines:
            try:
                key, value = line.split('=')
            except ValueError:
                pass
            else:
                key = key.strip()
                if key == 'version':
                    version = value.strip()
                elif key == 'download_link':
                    downloadUrl = value.strip()
        majorVersion, minorVersion, patchlevel = version.split('.')
        return int(majorVersion), int(minorVersion), int(patchlevel), downloadUrl

    def _update_available(self, latest, current):
        print(f'Latest  : {latest}')
        print(f'Current : {current}')
        if latest[0] > current[0]:
            return True

        if latest[0] == current[0]:
            if latest[1] > current[1]:
                return True

            if latest[1] == current[1]:
                if latest[2] > current[2]:
                    return True

        return False

